#!/bin/sh
# ----------------------------------------------------------------
# Monitoring Agent for ActiveMQ
# Version 100
# Unix Java Provider Launcher Script
#
# IBM
#
# This file was created by IBM Agent Builder
# Version 6.3.4
#	Agent Builder Common.v6.3.4 201703151048
#	IBM Tivoli Monitoring Agent Generator.v6.3.4 201703151048
#	IBM Agent Builder UI.v6.3.4 201703151048
#	IBM Tivoli Monitoring OSLC Plugin.v6.3.4 201703151048
#	Agent Builder CIM Data Provider.v6.3.4 201703151048
#	Agent Builder Custom Data Provider.v6.3.4 201703151048
#	Agent Builder HTTP Data Provider.v6.3.4 201703151048
#	Agent Builder ICMP Data Provider.v6.3.4 201703151048
#	IBM Tivoli Monitoring JDBC Data Provider.v6.3.4 201703151048
#	IBM Tivoli Monitoring JMX Data Provider.v6.3.4 201703151048
#	Agent Builder Log Data Provider.v6.3.4 201703151048
#	Agent Builder SNMP Data Provider.v6.3.4 201703151048
#	Agent Builder WMI Data Provider.v6.3.4 201703151048
#	IBM Tivoli Monitoring TMS DLA Plugin.v6.3.4 201703151048
#	Agent Builder Dashboard Support.v6.3.4 201703151048
#	IBM Tivoli Monitoring Remote Deploy.v6.3.4 201703151048
#	IBM Tivoli Omnibus.v6.3.4 201703151048
# ----------------------------------------------------------------

if [ -n "$JAVAHOME" -a -d "$JAVAHOME" ]; then
   PATH=$JAVAHOME/jre/bin:$PATH
fi

if [ -n "$JAVA_HOME" ]; then
   PATH=$JAVA_HOME/bin:$JAVA_HOME/jre/bin:$JAVA_HOME:$PATH
fi

INSTANCE=$KAQ_INSTANCE_NAME
if [ -z "$INSTANCE" ]; then
        INSTANCE=.
fi

TYPE=JMX
CLASSNAME=com.ibm.tivoli.monitoring.jat.AgentControl
if [ -n "$1" ]; then
   CLASSNAME=$1
   LOAD_CUSTOM_JARS=true
else
   COMMAND_ARGS="$TYPE $CANDLEHOME $INSTANCE $KQZ_PRODUCT_CODE"
fi

PC=aq
if [ -z "$LOAD_CUSTOM_JARS" ]; then
USE_CLASS_PATH=$CANDLEHOME/$ITM_BINARCH/$PC/classes:$CANDLEHOME/$ITM_BINARCH/$PC/jars/common/jatlib-1.0.jar:$CANDLEHOME/$ITM_BINARCH/$PC/jars/jlog.jar:$CANDLEHOME/$ITM_BINARCH/$PC/jars/cpci.jar
else
USE_CLASS_PATH=$CANDLEHOME/$ITM_BINARCH/$PC/jars/common/jatlib-1.0.jar:$CANDLEHOME/$ITM_BINARCH/$PC/jars/cpci.jar:$KQZ_CUSTOM_CLASS_PATH
fi

###################################################################
# Setup WebSphere properties if this is a WAS connection
# look for setupCmdLine.sh to determine if we are WebSphere
OIFS=$IFS
IFS=';:'
for basepath in $JAVA_BASE_PATHS:$KQZ_JMX_WAS_WAS60_BASE_PATHS:$KQZ_JMX_WAS_WAS61_BASE_PATHS:$KQZ_JMX_WAS_WAS70_BASE_PATHS:$KQZ_JMX_JSR160WAS_WAS_BASE_PATHS; do
   basepath=`echo "$basepath" | sed 's/://g'`
   if [ -f "$basepath/bin/setupCmdLine.sh" ]; then
      REPLACE_WAS_HOME="$basepath"
      if [ -n "$WAS_PROFILE_NAME" ]; then
         . "$basepath/bin/setupCmdLine.sh" -profileName "$WAS_PROFILE_NAME"
      else
         . "$basepath/bin/setupCmdLine.sh"
      fi
      # add jars from the config to the classpath
      if [ -n "$WAS_CLASSPATH" ]; then
         for jarfile in $KQZ_JMX_WAS_WAS61_JAR_FILES:$KQZ_JMX_WAS_WAS60_JAR_FILES:$KQZ_JMX_WAS_WAS70_JAR_FILES:$KQZ_JMX_JSR160WAS_WAS_JAR_FILES; do
            jarfile=`echo "$jarfile" | sed 's/://g'`
            USE_CLASS_PATH=$USE_CLASS_PATH:$basepath/$jarfile
         done
      fi
      # add discovered jars to the classpath
         if [ -d "$basepath/runtimes" ]; then
         ADMIN_JAR=`ls "$basepath/runtimes" | grep "admin.client.*.jar"`
         if [ -n "$ADMIN_JAR" ]; then
            USE_CLASS_PATH="$USE_CLASS_PATH:$basepath/runtimes/$ADMIN_JAR"
         fi
      fi
      if [ -d "$basepath/plugins" ]; then
         ADMIN_JAR=`ls "$basepath/plugins" | grep "security.crypto.*.jar"`
         if [ -n "$ADMIN_JAR" ]; then
            USE_CLASS_PATH="$USE_CLASS_PATH:$basepath/plugins/$ADMIN_JAR"
         fi
         ADMIN_JAR=`ls "$basepath/plugins" | grep "javax.j2ee.management.*.jar"`
         if [ -n "$ADMIN_JAR" ]; then
            USE_CLASS_PATH="$USE_CLASS_PATH:$basepath/plugins/$ADMIN_JAR"
         fi
      fi
      # add other arguments to the cmd
      if [ -n "$WAS_LOGGING" ]; then
         JAVA_JVM_ARGS="$JAVA_JVM_ARGS $WAS_LOGGING"
      fi
      JAVA_JVM_ARGS="$JAVA_JVM_ARGS -Dcom.ibm.SOAP.loginSource=none -Dcom.ibm.CORBA.loginSource=none"
      break;
   fi
done
IFS=$OIFS
# End of WebSphere setup
###################################################################

JVERSION=`java -version`
if [ $? -ne 0 ]; then
        echo "Error: Cannot find the configured java runtime from the path: $PATH" >> $CANDLEHOME/logs/k${PC}_${TYPE}_trace.log
        ITMJAVA=`$CANDLEHOME/bin/CandleGetJavaHome`
        PATH=$ITMJAVA/bin:$ITMJAVA/jre/bin:$PATH
        JVERSION=`java -version`
        if [ $? -ne 0 ]; then
                echo "Error: Could not find the ITM java runtime at: $ITMJAVA" >> $CANDLEHOME/logs/k${PC}_${TYPE}_trace.log
                echo "Error: The java custom provider cannot be started." >> $CANDLEHOME/logs/k${PC}_${TYPE}_trace.log
                exit 127
        fi
        echo "Using the java runtime included with ITM: $ITMJAVA" >> $CANDLEHOME/logs/k${PC}_${TYPE}_trace.log
fi
exec java -Djava.class.path=$USE_CLASS_PATH $CLIENTSAS $CLIENTSOAP $CLIENTSSL -DAGENT_REF_FILE=$AGENT_REF_FILE -DBINARCH=$ITM_BINARCH -DCP_PORT=$CP_PORT -DJAVA_TRACE_LEVEL=$JAVA_TRACE_LEVEL $JAVA_JVM_ARGS $CLASSNAME $COMMAND_ARGS

