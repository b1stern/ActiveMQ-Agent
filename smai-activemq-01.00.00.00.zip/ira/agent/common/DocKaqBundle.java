/*
 COPYRIGHT_COMMENT_TAG_BEGIN
 IBM Confidential
 OCO Source Materials
 5724-C04
 
 Copyright IBM Corp. 2005, 2011
 The source code for this program is not published or otherwise
 divested of its trade secrets, irrespective of what has
 been deposited with the U.S. Copyright Office.
 COPYRIGHT_COMMENT_TAG_END
 */
//***************************************************************************
//                                                                          *
// Unpublished Copyright (c) 1998, 2004 Candle Corporation.                 *
//                                                                          *
// All rights reserved.  International copyright secured.                   *
// USE PERMISSIBLE UNDER LICENSE ONLY.  This software may be                *
// protected by one or more United States and/or international              *
// patents or pending patent applications.                                  *
//                                                                          *
//***************************************************************************

/**
 * Resources
 * NLS_MESSAGEFORMAT_NONE (CHKPII flag indicating that the text is not 
 *                         processed by Java MessageFormat class)
 */

//***************************************************************************
//                >>>>  M A I N T E N A N C E    L O G  <<<<                *
//***************************************************************************
//  $Date: September 2, 2017 3:03:04 PM EDT $
//  $Revision: 1.0 $
//
//***************************************************************************

// NLS_ENCODING=UTF-8
package candle.kaq.resources;

import candle.kjr.resource.*;
import candle.kjr.util.*;
import java.util.*;
import java.lang.reflect.Method;

/**
 * <code>DocKaqBundle</code> contains Kaq ODI definitions for NLS.
 *
 */

public class DocKaqBundle extends ResourceBundle implements Versioned
{
  private static final long serialVersionUID = 1L;

  private static final String BUNDLE_ID       = "dockaq";
  private static final String BUNDLE_NAME     = "candle.kaq.resources.DocKaqBundle";

  private static final IntegerVersion version = new IntegerVersion(100);

  // public Object[][] getContents() - needed for CHKPII tool
  
public Object[][] _oM1()
{
Object[][] contents = 
{
        {"%IBM.KAQ",                                      "ActiveMQ"},
};
return contents;
}

public Object[][] _oM2()
{
Object[][] contents = 
{
        {"TABLE.KAQQUEUE.OBJECT",                         "KAQ QUEUE"},
        {"KAQQUEUE.ORIGINNODE",                           "Node"},

        {"KAQQUEUE.TIMESTAMP",                            "Timestamp"},

        {"KAQQUEUE.CURSORPERC",                           "CursorPercentUsage"},
        {"KAQQUEUE.CURSORPERC.ENUM.-2147483648",          "Value Exceeds Minimum"},
        {"KAQQUEUE.CURSORPERC.ENUM.2147483647",           "Value Exceeds Maximum"},

        {"KAQQUEUE.NAME",                                 "Name"},

        {"KAQQUEUE.ENQUEUECOU",                           "EnqueueCount"},
        {"KAQQUEUE.ENQUEUECOU.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQQUEUE.ENQUEUECOU.ENUM.9223372036854775807",  "Value Exceeds Maximum"},

        {"KAQQUEUE.DISPATCHCO",                           "DispatchCount"},
        {"KAQQUEUE.DISPATCHCO.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQQUEUE.DISPATCHCO.ENUM.9223372036854775807",  "Value Exceeds Maximum"},

        {"KAQQUEUE.DEQUEUECOU",                           "DequeueCount"},
        {"KAQQUEUE.DEQUEUECOU.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQQUEUE.DEQUEUECOU.ENUM.9223372036854775807",  "Value Exceeds Maximum"},

        {"KAQQUEUE.FORWARDCOU",                           "ForwardCount"},
        {"KAQQUEUE.FORWARDCOU.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQQUEUE.FORWARDCOU.ENUM.9223372036854775807",  "Value Exceeds Maximum"},

        {"KAQQUEUE.INFLIGHTCO",                           "InFlightCount"},
        {"KAQQUEUE.INFLIGHTCO.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQQUEUE.INFLIGHTCO.ENUM.9223372036854775807",  "Value Exceeds Maximum"},

        {"KAQQUEUE.EXPIREDCOU",                           "ExpiredCount"},
        {"KAQQUEUE.EXPIREDCOU.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQQUEUE.EXPIREDCOU.ENUM.9223372036854775807",  "Value Exceeds Maximum"},

        {"KAQQUEUE.CONSUMERCO",                           "ConsumerCount"},
        {"KAQQUEUE.CONSUMERCO.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQQUEUE.CONSUMERCO.ENUM.9223372036854775807",  "Value Exceeds Maximum"},

        {"KAQQUEUE.PRODUCERCO",                           "ProducerCount"},
        {"KAQQUEUE.PRODUCERCO.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQQUEUE.PRODUCERCO.ENUM.9223372036854775807",  "Value Exceeds Maximum"},

        {"KAQQUEUE.QUEUESIZE",                            "QueueSize"},
        {"KAQQUEUE.QUEUESIZE.ENUM.-9223372036854775808",  "Value Exceeds Minimum"},
        {"KAQQUEUE.QUEUESIZE.ENUM.9223372036854775807",   "Value Exceeds Maximum"},

        {"KAQQUEUE.MEMORYPERC",                           "MemoryPercentUsage"},
        {"KAQQUEUE.MEMORYPERC.ENUM.-2147483648",          "Value Exceeds Minimum"},
        {"KAQQUEUE.MEMORYPERC.ENUM.2147483647",           "Value Exceeds Maximum"},

        {"KAQQUEUE.MAXENQUEUE",                           "MaxEnqueueTime"},
        {"KAQQUEUE.MAXENQUEUE.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQQUEUE.MAXENQUEUE.ENUM.9223372036854775807",  "Value Exceeds Maximum"},

        {"KAQQUEUE.MINENQUEUE",                           "MinEnqueueTime"},
        {"KAQQUEUE.MINENQUEUE.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQQUEUE.MINENQUEUE.ENUM.9223372036854775807",  "Value Exceeds Maximum"},

        {"KAQQUEUE.AVERAGEENQ",                           "AverageEnqueueTime"},
        {"KAQQUEUE.AVERAGEENQ.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQQUEUE.AVERAGEENQ.ENUM.9223372036854775807",  "Value Exceeds Maximum"},

        {"KAQQUEUE.AVERAGEMES",                           "AverageMessageSize"},
        {"KAQQUEUE.AVERAGEMES.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQQUEUE.AVERAGEMES.ENUM.9223372036854775807",  "Value Exceeds Maximum"},

        {"KAQQUEUE.BLOCKEDSEN",                           "BlockedSends"},
        {"KAQQUEUE.BLOCKEDSEN.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQQUEUE.BLOCKEDSEN.ENUM.9223372036854775807",  "Value Exceeds Maximum"},

        {"KAQQUEUE.AVERAGEBLO",                           "AverageBlockedTime"},
        {"KAQQUEUE.AVERAGEBLO.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQQUEUE.AVERAGEBLO.ENUM.9223372036854775807",  "Value Exceeds Maximum"},

        {"KAQQUEUE.TOTALBLOCK",                           "TotalBlockedTime"},
        {"KAQQUEUE.TOTALBLOCK.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQQUEUE.TOTALBLOCK.ENUM.9223372036854775807",  "Value Exceeds Maximum"},

        {"KAQQUEUE.CATCHUPTIM",                           "CatchUpTime"},
        {"KAQQUEUE.CATCHUPTIM.ENUM.-2147483648",          "Value Exceeds Minimum"},
        {"KAQQUEUE.CATCHUPTIM.ENUM.2147483647",           "Value Exceeds Maximum"},

};
return contents;
}

public Object[][] _oM3()
{
Object[][] contents = 
{
        {"TABLE.KAQTOPIC.OBJECT",                         "KAQ TOPIC"},
        {"KAQTOPIC.ORIGINNODE",                           "Node"},

        {"KAQTOPIC.TIMESTAMP",                            "Timestamp"},

        {"KAQTOPIC.NAME",                                 "Name"},

        {"KAQTOPIC.ENQUEUECOU",                           "EnqueueCount"},
        {"KAQTOPIC.ENQUEUECOU.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQTOPIC.ENQUEUECOU.ENUM.9223372036854775807",  "Value Exceeds Maximum"},

        {"KAQTOPIC.DISPATCHCO",                           "DispatchCount"},
        {"KAQTOPIC.DISPATCHCO.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQTOPIC.DISPATCHCO.ENUM.9223372036854775807",  "Value Exceeds Maximum"},

        {"KAQTOPIC.DEQUEUECOU",                           "DequeueCount"},
        {"KAQTOPIC.DEQUEUECOU.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQTOPIC.DEQUEUECOU.ENUM.9223372036854775807",  "Value Exceeds Maximum"},

        {"KAQTOPIC.FORWARDCOU",                           "ForwardCount"},
        {"KAQTOPIC.FORWARDCOU.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQTOPIC.FORWARDCOU.ENUM.9223372036854775807",  "Value Exceeds Maximum"},

        {"KAQTOPIC.INFLIGHTCO",                           "InFlightCount"},
        {"KAQTOPIC.INFLIGHTCO.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQTOPIC.INFLIGHTCO.ENUM.9223372036854775807",  "Value Exceeds Maximum"},

        {"KAQTOPIC.EXPIREDCOU",                           "ExpiredCount"},
        {"KAQTOPIC.EXPIREDCOU.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQTOPIC.EXPIREDCOU.ENUM.9223372036854775807",  "Value Exceeds Maximum"},

        {"KAQTOPIC.CONSUMERCO",                           "ConsumerCount"},
        {"KAQTOPIC.CONSUMERCO.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQTOPIC.CONSUMERCO.ENUM.9223372036854775807",  "Value Exceeds Maximum"},

        {"KAQTOPIC.PRODUCERCO",                           "ProducerCount"},
        {"KAQTOPIC.PRODUCERCO.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQTOPIC.PRODUCERCO.ENUM.9223372036854775807",  "Value Exceeds Maximum"},

        {"KAQTOPIC.QUEUESIZE",                            "QueueSize"},
        {"KAQTOPIC.QUEUESIZE.ENUM.-9223372036854775808",  "Value Exceeds Minimum"},
        {"KAQTOPIC.QUEUESIZE.ENUM.9223372036854775807",   "Value Exceeds Maximum"},

        {"KAQTOPIC.STOREMESSA",                           "StoreMessageSize"},
        {"KAQTOPIC.STOREMESSA.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQTOPIC.STOREMESSA.ENUM.9223372036854775807",  "Value Exceeds Maximum"},

        {"KAQTOPIC.MEMORYPERC",                           "MemoryPercentUsage"},
        {"KAQTOPIC.MEMORYPERC.ENUM.-2147483648",          "Value Exceeds Minimum"},
        {"KAQTOPIC.MEMORYPERC.ENUM.2147483647",           "Value Exceeds Maximum"},

        {"KAQTOPIC.MAXENQUEUE",                           "MaxEnqueueTime"},
        {"KAQTOPIC.MAXENQUEUE.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQTOPIC.MAXENQUEUE.ENUM.9223372036854775807",  "Value Exceeds Maximum"},

        {"KAQTOPIC.AVERAGEENQ",                           "AverageEnqueueTime"},
        {"KAQTOPIC.AVERAGEENQ.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQTOPIC.AVERAGEENQ.ENUM.9223372036854775807",  "Value Exceeds Maximum"},

        {"KAQTOPIC.AVERAGEMES",                           "AverageMessageSize"},
        {"KAQTOPIC.AVERAGEMES.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQTOPIC.AVERAGEMES.ENUM.9223372036854775807",  "Value Exceeds Maximum"},

        {"KAQTOPIC.SUBSCRIPTI",                           "Subscriptions"},
        {"KAQTOPIC.SUBSCRIPTI.ENUM.-2147483648",          "Value Exceeds Minimum"},
        {"KAQTOPIC.SUBSCRIPTI.ENUM.2147483647",           "Value Exceeds Maximum"},

        {"KAQTOPIC.BLOCKEDSEN",                           "BlockedSends"},
        {"KAQTOPIC.BLOCKEDSEN.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQTOPIC.BLOCKEDSEN.ENUM.9223372036854775807",  "Value Exceeds Maximum"},

        {"KAQTOPIC.AVERAGEBLO",                           "AverageBlockedTime"},
        {"KAQTOPIC.AVERAGEBLO.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQTOPIC.AVERAGEBLO.ENUM.9223372036854775807",  "Value Exceeds Maximum"},

};
return contents;
}

public Object[][] _oM4()
{
Object[][] contents = 
{
        {"TABLE.KAQHEALTH.OBJECT",                        "KAQ HEALTH"},
        {"KAQHEALTH.ORIGINNODE",                          "Node"},

        {"KAQHEALTH.TIMESTAMP",                           "Timestamp"},

        {"KAQHEALTH.CURRENTSTA",                          "CurrentStatus"},

};
return contents;
}

public Object[][] _oM5()
{
Object[][] contents = 
{
        {"TABLE.KAQTHREADI.OBJECT",                       "KAQ THREADING"},
        {"KAQTHREADI.ORIGINNODE",                         "Node"},

        {"KAQTHREADI.TIMESTAMP",                          "Timestamp"},

        {"KAQTHREADI.DAEMONTHRE",                         "DaemonThreadCount"},
        {"KAQTHREADI.DAEMONTHRE.ENUM.-2147483648",        "Value Exceeds Minimum"},
        {"KAQTHREADI.DAEMONTHRE.ENUM.2147483647",         "Value Exceeds Maximum"},

        {"KAQTHREADI.PEAKTHREAD",                         "PeakThreadCount"},
        {"KAQTHREADI.PEAKTHREAD.ENUM.-2147483648",        "Value Exceeds Minimum"},
        {"KAQTHREADI.PEAKTHREAD.ENUM.2147483647",         "Value Exceeds Maximum"},

        {"KAQTHREADI.CURRENTTH0",                         "CurrentThreadCpuTime"},
        {"KAQTHREADI.CURRENTTH0.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQTHREADI.CURRENTTH0.ENUM.9223372036854775807", "Value Exceeds Maximum"},

        {"KAQTHREADI.CURRENTTH1",                         "CurrentThreadUserTime"},
        {"KAQTHREADI.CURRENTTH1.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQTHREADI.CURRENTTH1.ENUM.9223372036854775807", "Value Exceeds Maximum"},

        {"KAQTHREADI.THREADCOUN",                         "ThreadCount"},
        {"KAQTHREADI.THREADCOUN.ENUM.-2147483648",        "Value Exceeds Minimum"},
        {"KAQTHREADI.THREADCOUN.ENUM.2147483647",         "Value Exceeds Maximum"},

        {"KAQTHREADI.TOTALSTART",                         "TotalStartedThreadCount"},
        {"KAQTHREADI.TOTALSTART.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQTHREADI.TOTALSTART.ENUM.9223372036854775807", "Value Exceeds Maximum"},

};
return contents;
}

public Object[][] _oM6()
{
Object[][] contents = 
{
        {"TABLE.KAQBROKER.OBJECT",                        "KAQ BROKER"},
        {"KAQBROKER.ORIGINNODE",                          "Node"},

        {"KAQBROKER.TIMESTAMP",                           "Timestamp"},

        {"KAQBROKER.TOTALENQUE",                          "TotalEnqueueCount"},
        {"KAQBROKER.TOTALENQUE.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQBROKER.TOTALENQUE.ENUM.9223372036854775807", "Value Exceeds Maximum"},

        {"KAQBROKER.TOTALDEQUE",                          "TotalDequeueCount"},
        {"KAQBROKER.TOTALDEQUE.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQBROKER.TOTALDEQUE.ENUM.9223372036854775807", "Value Exceeds Maximum"},

        {"KAQBROKER.TOTALCONSU",                          "TotalConsumerCount"},
        {"KAQBROKER.TOTALCONSU.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQBROKER.TOTALCONSU.ENUM.9223372036854775807", "Value Exceeds Maximum"},

        {"KAQBROKER.TOTALPRODU",                          "TotalProducerCount"},
        {"KAQBROKER.TOTALPRODU.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQBROKER.TOTALPRODU.ENUM.9223372036854775807", "Value Exceeds Maximum"},

        {"KAQBROKER.TOTALMESSA",                          "TotalMessageCount"},
        {"KAQBROKER.TOTALMESSA.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQBROKER.TOTALMESSA.ENUM.9223372036854775807", "Value Exceeds Maximum"},

        {"KAQBROKER.AVERAGEMES",                          "AverageMessageSize"},
        {"KAQBROKER.AVERAGEMES.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQBROKER.AVERAGEMES.ENUM.9223372036854775807", "Value Exceeds Maximum"},

        {"KAQBROKER.STOREPERCE",                          "StorePercentUsage"},
        {"KAQBROKER.STOREPERCE.ENUM.-2147483648",         "Value Exceeds Minimum"},
        {"KAQBROKER.STOREPERCE.ENUM.2147483647",          "Value Exceeds Maximum"},

        {"KAQBROKER.TEMPPERCEN",                          "TempPercentUsage"},
        {"KAQBROKER.TEMPPERCEN.ENUM.-2147483648",         "Value Exceeds Minimum"},
        {"KAQBROKER.TEMPPERCEN.ENUM.2147483647",          "Value Exceeds Maximum"},

        {"KAQBROKER.INACTIVEDU",                          "InactiveDurableTopicSubscribers"},
        {"KAQBROKER.INACTIVEDU.ENUM.-2147483648",         "Value Exceeds Minimum"},
        {"KAQBROKER.INACTIVEDU.ENUM.2147483647",          "Value Exceeds Maximum"},

        {"KAQBROKER.TOPICSUBSC",                          "TopicSubscribers"},
        {"KAQBROKER.TOPICSUBSC.ENUM.-2147483648",         "Value Exceeds Minimum"},
        {"KAQBROKER.TOPICSUBSC.ENUM.2147483647",          "Value Exceeds Maximum"},

        {"KAQBROKER.DURABLETOP",                          "DurableTopicSubscribers"},
        {"KAQBROKER.DURABLETOP.ENUM.-2147483648",         "Value Exceeds Minimum"},
        {"KAQBROKER.DURABLETOP.ENUM.2147483647",          "Value Exceeds Maximum"},

        {"KAQBROKER.QUEUESUBSC",                          "QueueSubscribers"},
        {"KAQBROKER.QUEUESUBSC.ENUM.-2147483648",         "Value Exceeds Minimum"},
        {"KAQBROKER.QUEUESUBSC.ENUM.2147483647",          "Value Exceeds Maximum"},

        {"KAQBROKER.TEMPORARY0",                          "TemporaryTopicSubscribers"},
        {"KAQBROKER.TEMPORARY0.ENUM.-2147483648",         "Value Exceeds Minimum"},
        {"KAQBROKER.TEMPORARY0.ENUM.2147483647",          "Value Exceeds Maximum"},

        {"KAQBROKER.TEMPORARY1",                          "TemporaryQueueSubscribers"},
        {"KAQBROKER.TEMPORARY1.ENUM.-2147483648",         "Value Exceeds Minimum"},
        {"KAQBROKER.TEMPORARY1.ENUM.2147483647",          "Value Exceeds Maximum"},

        {"KAQBROKER.TOPICPRODU",                          "TopicProducers"},
        {"KAQBROKER.TOPICPRODU.ENUM.-2147483648",         "Value Exceeds Minimum"},
        {"KAQBROKER.TOPICPRODU.ENUM.2147483647",          "Value Exceeds Maximum"},

        {"KAQBROKER.QUEUEPRODU",                          "QueueProducers"},
        {"KAQBROKER.QUEUEPRODU.ENUM.-2147483648",         "Value Exceeds Minimum"},
        {"KAQBROKER.QUEUEPRODU.ENUM.2147483647",          "Value Exceeds Maximum"},

        {"KAQBROKER.TEMPORARY2",                          "TemporaryTopicProducers"},
        {"KAQBROKER.TEMPORARY2.ENUM.-2147483648",         "Value Exceeds Minimum"},
        {"KAQBROKER.TEMPORARY2.ENUM.2147483647",          "Value Exceeds Maximum"},

        {"KAQBROKER.TEMPORARY3",                          "TemporaryQueueProducers"},
        {"KAQBROKER.TEMPORARY3.ENUM.-2147483648",         "Value Exceeds Minimum"},
        {"KAQBROKER.TEMPORARY3.ENUM.2147483647",          "Value Exceeds Maximum"},

        {"KAQBROKER.DYNAMICDES",                          "DynamicDestinationProducers"},
        {"KAQBROKER.DYNAMICDES.ENUM.-2147483648",         "Value Exceeds Minimum"},
        {"KAQBROKER.DYNAMICDES.ENUM.2147483647",          "Value Exceeds Maximum"},

        {"KAQBROKER.CURRENTCON",                          "CurrentConnectionsCount"},
        {"KAQBROKER.CURRENTCON.ENUM.-2147483648",         "Value Exceeds Minimum"},
        {"KAQBROKER.CURRENTCON.ENUM.2147483647",          "Value Exceeds Maximum"},

        {"KAQBROKER.TOTALCONNE",                          "TotalConnectionsCount"},
        {"KAQBROKER.TOTALCONNE.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQBROKER.TOTALCONNE.ENUM.9223372036854775807", "Value Exceeds Maximum"},

        {"KAQBROKER.BROKERNAME",                          "BrokerName"},

};
return contents;
}

public Object[][] _oM7()
{
Object[][] contents = 
{
        {"TABLE.KAQUTILIZA.OBJECT",                       "KAQ UTILIZATION"},
        {"KAQUTILIZA.ORIGINNODE",                         "Node"},

        {"KAQUTILIZA.TIMESTAMP",                          "Timestamp"},

        {"KAQUTILIZA.OBJECTNAME",                         "ObjectName"},

        {"KAQUTILIZA.PROCESSUTI",                         "ProcessUtilization"},
        {"KAQUTILIZA.PROCESSUTI.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQUTILIZA.PROCESSUTI.ENUM.9223372036854775807", "Value Exceeds Maximum"},

        {"KAQUTILIZA.PROCESSORU",                         "ProcessorUtilization"},
        {"KAQUTILIZA.PROCESSORU.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQUTILIZA.PROCESSORU.ENUM.9223372036854775807", "Value Exceeds Maximum"},

};
return contents;
}

public Object[][] _oM8()
{
Object[][] contents = 
{
        {"TABLE.KAQMEMORY.OBJECT",                        "KAQ MEMORY"},
        {"KAQMEMORY.ORIGINNODE",                          "Node"},

        {"KAQMEMORY.TIMESTAMP",                           "Timestamp"},

        {"KAQMEMORY.HEAPMEMORY",                          "HeapMemoryUsage committed"},
        {"KAQMEMORY.HEAPMEMORY.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQMEMORY.HEAPMEMORY.ENUM.9223372036854775807", "Value Exceeds Maximum"},

        {"KAQMEMORY.HEAPMEMOR1",                          "HeapMemoryUsage max"},
        {"KAQMEMORY.HEAPMEMOR1.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQMEMORY.HEAPMEMOR1.ENUM.9223372036854775807", "Value Exceeds Maximum"},

        {"KAQMEMORY.HEAPMEMOR2",                          "HeapMemoryUsage used"},
        {"KAQMEMORY.HEAPMEMOR2.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQMEMORY.HEAPMEMOR2.ENUM.9223372036854775807", "Value Exceeds Maximum"},

        {"KAQMEMORY.OBJECTNAME",                          "ObjectName"},

        {"KAQMEMORY.PERCENTHEA",                          "PercentHeapUsed"},
        {"KAQMEMORY.PERCENTHEA.ENUM.-2147483648",         "Value Exceeds Minimum"},
        {"KAQMEMORY.PERCENTHEA.ENUM.2147483647",          "Value Exceeds Maximum"},

};
return contents;
}

public Object[][] _oM9()
{
Object[][] contents = 
{
        {"TABLE.KAQMEMORYP.OBJECT",                       "KAQ MEMORYPOOL"},
        {"KAQMEMORYP.ORIGINNODE",                         "Node"},

        {"KAQMEMORYP.TIMESTAMP",                          "Timestamp"},

        {"KAQMEMORYP.NAME",                               "Name"},

        {"KAQMEMORYP.USAGE_COMM",                         "Usage committed"},
        {"KAQMEMORYP.USAGE_COMM.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQMEMORYP.USAGE_COMM.ENUM.9223372036854775807", "Value Exceeds Maximum"},

        {"KAQMEMORYP.USAGE_MAX",                          "Usage max"},
        {"KAQMEMORYP.USAGE_MAX.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQMEMORYP.USAGE_MAX.ENUM.9223372036854775807", "Value Exceeds Maximum"},

        {"KAQMEMORYP.USAGE_USED",                         "Usage used"},
        {"KAQMEMORYP.USAGE_USED.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQMEMORYP.USAGE_USED.ENUM.9223372036854775807", "Value Exceeds Maximum"},

        {"KAQMEMORYP.PERCENTUSE",                         "PercentUsed"},
        {"KAQMEMORYP.PERCENTUSE.ENUM.-2147483648",        "Value Exceeds Minimum"},
        {"KAQMEMORYP.PERCENTUSE.ENUM.2147483647",         "Value Exceeds Maximum"},

};
return contents;
}

public Object[][] _oM10()
{
Object[][] contents = 
{
        {"TABLE.KAQDEADLET.OBJECT",                       "KAQ DEADLETTERQUEUE"},
        {"KAQDEADLET.ORIGINNODE",                         "Node"},

        {"KAQDEADLET.TIMESTAMP",                          "Timestamp"},

        {"KAQDEADLET.CURSORPERC",                         "CursorPercentUsage"},
        {"KAQDEADLET.CURSORPERC.ENUM.-2147483648",        "Value Exceeds Minimum"},
        {"KAQDEADLET.CURSORPERC.ENUM.2147483647",         "Value Exceeds Maximum"},

        {"KAQDEADLET.NAME",                               "Name"},

        {"KAQDEADLET.ENQUEUECOU",                         "EnqueueCount"},
        {"KAQDEADLET.ENQUEUECOU.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQDEADLET.ENQUEUECOU.ENUM.9223372036854775807", "Value Exceeds Maximum"},

        {"KAQDEADLET.DISPATCHCO",                         "DispatchCount"},
        {"KAQDEADLET.DISPATCHCO.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQDEADLET.DISPATCHCO.ENUM.9223372036854775807", "Value Exceeds Maximum"},

        {"KAQDEADLET.DEQUEUECOU",                         "DequeueCount"},
        {"KAQDEADLET.DEQUEUECOU.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQDEADLET.DEQUEUECOU.ENUM.9223372036854775807", "Value Exceeds Maximum"},

        {"KAQDEADLET.FORWARDCOU",                         "ForwardCount"},
        {"KAQDEADLET.FORWARDCOU.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQDEADLET.FORWARDCOU.ENUM.9223372036854775807", "Value Exceeds Maximum"},

        {"KAQDEADLET.INFLIGHTCO",                         "InFlightCount"},
        {"KAQDEADLET.INFLIGHTCO.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQDEADLET.INFLIGHTCO.ENUM.9223372036854775807", "Value Exceeds Maximum"},

        {"KAQDEADLET.EXPIREDCOU",                         "ExpiredCount"},
        {"KAQDEADLET.EXPIREDCOU.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQDEADLET.EXPIREDCOU.ENUM.9223372036854775807", "Value Exceeds Maximum"},

        {"KAQDEADLET.CONSUMERCO",                         "ConsumerCount"},
        {"KAQDEADLET.CONSUMERCO.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQDEADLET.CONSUMERCO.ENUM.9223372036854775807", "Value Exceeds Maximum"},

        {"KAQDEADLET.PRODUCERCO",                         "ProducerCount"},
        {"KAQDEADLET.PRODUCERCO.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQDEADLET.PRODUCERCO.ENUM.9223372036854775807", "Value Exceeds Maximum"},

        {"KAQDEADLET.QUEUESIZE",                          "QueueSize"},
        {"KAQDEADLET.QUEUESIZE.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQDEADLET.QUEUESIZE.ENUM.9223372036854775807", "Value Exceeds Maximum"},

        {"KAQDEADLET.MEMORYPERC",                         "MemoryPercentUsage"},
        {"KAQDEADLET.MEMORYPERC.ENUM.-2147483648",        "Value Exceeds Minimum"},
        {"KAQDEADLET.MEMORYPERC.ENUM.2147483647",         "Value Exceeds Maximum"},

        {"KAQDEADLET.MAXENQUEUE",                         "MaxEnqueueTime"},
        {"KAQDEADLET.MAXENQUEUE.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQDEADLET.MAXENQUEUE.ENUM.9223372036854775807", "Value Exceeds Maximum"},

        {"KAQDEADLET.MINENQUEUE",                         "MinEnqueueTime"},
        {"KAQDEADLET.MINENQUEUE.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQDEADLET.MINENQUEUE.ENUM.9223372036854775807", "Value Exceeds Maximum"},

        {"KAQDEADLET.AVERAGEENQ",                         "AverageEnqueueTime"},
        {"KAQDEADLET.AVERAGEENQ.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQDEADLET.AVERAGEENQ.ENUM.9223372036854775807", "Value Exceeds Maximum"},

        {"KAQDEADLET.AVERAGEMES",                         "AverageMessageSize"},
        {"KAQDEADLET.AVERAGEMES.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQDEADLET.AVERAGEMES.ENUM.9223372036854775807", "Value Exceeds Maximum"},

        {"KAQDEADLET.BLOCKEDSEN",                         "BlockedSends"},
        {"KAQDEADLET.BLOCKEDSEN.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQDEADLET.BLOCKEDSEN.ENUM.9223372036854775807", "Value Exceeds Maximum"},

        {"KAQDEADLET.AVERAGEBLO",                         "AverageBlockedTime"},
        {"KAQDEADLET.AVERAGEBLO.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQDEADLET.AVERAGEBLO.ENUM.9223372036854775807", "Value Exceeds Maximum"},

        {"KAQDEADLET.TOTALBLOCK",                         "TotalBlockedTime"},
        {"KAQDEADLET.TOTALBLOCK.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQDEADLET.TOTALBLOCK.ENUM.9223372036854775807", "Value Exceeds Maximum"},

        {"KAQDEADLET.CATCHUPTIM",                         "CatchUpTime"},
        {"KAQDEADLET.CATCHUPTIM.ENUM.-2147483648",        "Value Exceeds Minimum"},
        {"KAQDEADLET.CATCHUPTIM.ENUM.2147483647",         "Value Exceeds Maximum"},

};
return contents;
}

public Object[][] _oM11()
{
Object[][] contents = 
{
        {"TABLE.KAQHEAPEDE.OBJECT",                       "KAQ HEAPEDENSPACE"},
        {"KAQHEAPEDE.ORIGINNODE",                         "Node"},

        {"KAQHEAPEDE.TIMESTAMP",                          "Timestamp"},

        {"KAQHEAPEDE.NAME",                               "Name"},

        {"KAQHEAPEDE.USAGE_COMM",                         "Usage committed"},
        {"KAQHEAPEDE.USAGE_COMM.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQHEAPEDE.USAGE_COMM.ENUM.9223372036854775807", "Value Exceeds Maximum"},

        {"KAQHEAPEDE.USAGE_MAX",                          "Usage max"},
        {"KAQHEAPEDE.USAGE_MAX.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQHEAPEDE.USAGE_MAX.ENUM.9223372036854775807", "Value Exceeds Maximum"},

        {"KAQHEAPEDE.USAGE_USED",                         "Usage used"},
        {"KAQHEAPEDE.USAGE_USED.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQHEAPEDE.USAGE_USED.ENUM.9223372036854775807", "Value Exceeds Maximum"},

        {"KAQHEAPEDE.PERCENTUSE",                         "PercentUsed"},
        {"KAQHEAPEDE.PERCENTUSE.ENUM.-2147483648",        "Value Exceeds Minimum"},
        {"KAQHEAPEDE.PERCENTUSE.ENUM.2147483647",         "Value Exceeds Maximum"},

};
return contents;
}

public Object[][] _oM12()
{
Object[][] contents = 
{
        {"TABLE.KAQHEAPSUR.OBJECT",                       "KAQ HEAPSURVIVORSPACE"},
        {"KAQHEAPSUR.ORIGINNODE",                         "Node"},

        {"KAQHEAPSUR.TIMESTAMP",                          "Timestamp"},

        {"KAQHEAPSUR.NAME",                               "Name"},

        {"KAQHEAPSUR.USAGE_COMM",                         "Usage committed"},
        {"KAQHEAPSUR.USAGE_COMM.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQHEAPSUR.USAGE_COMM.ENUM.9223372036854775807", "Value Exceeds Maximum"},

        {"KAQHEAPSUR.USAGE_MAX",                          "Usage max"},
        {"KAQHEAPSUR.USAGE_MAX.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQHEAPSUR.USAGE_MAX.ENUM.9223372036854775807", "Value Exceeds Maximum"},

        {"KAQHEAPSUR.USAGE_USED",                         "Usage used"},
        {"KAQHEAPSUR.USAGE_USED.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQHEAPSUR.USAGE_USED.ENUM.9223372036854775807", "Value Exceeds Maximum"},

        {"KAQHEAPSUR.PERCENTUSE",                         "PercentUsed"},
        {"KAQHEAPSUR.PERCENTUSE.ENUM.-2147483648",        "Value Exceeds Minimum"},
        {"KAQHEAPSUR.PERCENTUSE.ENUM.2147483647",         "Value Exceeds Maximum"},

};
return contents;
}

public Object[][] _oM13()
{
Object[][] contents = 
{
        {"TABLE.KAQHEAPOLD.OBJECT",                       "KAQ HEAPOLDGEN"},
        {"KAQHEAPOLD.ORIGINNODE",                         "Node"},

        {"KAQHEAPOLD.TIMESTAMP",                          "Timestamp"},

        {"KAQHEAPOLD.NAME",                               "Name"},

        {"KAQHEAPOLD.USAGE_COMM",                         "Usage committed"},
        {"KAQHEAPOLD.USAGE_COMM.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQHEAPOLD.USAGE_COMM.ENUM.9223372036854775807", "Value Exceeds Maximum"},

        {"KAQHEAPOLD.USAGE_MAX",                          "Usage max"},
        {"KAQHEAPOLD.USAGE_MAX.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQHEAPOLD.USAGE_MAX.ENUM.9223372036854775807", "Value Exceeds Maximum"},

        {"KAQHEAPOLD.USAGE_USED",                         "Usage used"},
        {"KAQHEAPOLD.USAGE_USED.ENUM.-9223372036854775808", "Value Exceeds Minimum"},
        {"KAQHEAPOLD.USAGE_USED.ENUM.9223372036854775807", "Value Exceeds Maximum"},

        {"KAQHEAPOLD.PERCENTUSE",                         "PercentUsed"},
        {"KAQHEAPOLD.PERCENTUSE.ENUM.-2147483648",        "Value Exceeds Minimum"},
        {"KAQHEAPOLD.PERCENTUSE.ENUM.2147483647",         "Value Exceeds Maximum"},

};
return contents;
}

public Object[][] _oM14()
{
Object[][] contents = 
{
        {"TABLE.KAQPOBJST.OBJECT",                        "KAQ PERFORMANCE OBJECT STATUS"},
        {"KAQPOBJST.ORIGINNODE",                          "Node"},

        {"KAQPOBJST.TIMESTAMP",                           "Timestamp"},

        {"KAQPOBJST.ATTRGRP",                             "Query Name"},

        {"KAQPOBJST.OBJNAME",                             "Object Name"},

        {"KAQPOBJST.OBJTYPE",                             "Object Type"},
        {"KAQPOBJST.OBJTYPE.ENUM.0",                      "WMI"},
        {"KAQPOBJST.OBJTYPE.ENUM.1",                      "PERFMON"},
        {"KAQPOBJST.OBJTYPE.ENUM.10",                     "WMI REMOTE DATA"},
        {"KAQPOBJST.OBJTYPE.ENUM.11",                     "LOG FILE"},
        {"KAQPOBJST.OBJTYPE.ENUM.12",                     "JDBC"},
        {"KAQPOBJST.OBJTYPE.ENUM.13",                     "CONFIG DISCOVERY"},
        {"KAQPOBJST.OBJTYPE.ENUM.14",                     "NT EVENT LOG"},
        {"KAQPOBJST.OBJTYPE.ENUM.15",                     "FILTER"},
        {"KAQPOBJST.OBJTYPE.ENUM.16",                     "SNMP EVENT"},
        {"KAQPOBJST.OBJTYPE.ENUM.17",                     "PING"},
        {"KAQPOBJST.OBJTYPE.ENUM.18",                     "DIRECTOR DATA"},
        {"KAQPOBJST.OBJTYPE.ENUM.19",                     "DIRECTOR EVENT"},
        {"KAQPOBJST.OBJTYPE.ENUM.2",                      "WMI ASSOCIATION GROUP"},
        {"KAQPOBJST.OBJTYPE.ENUM.20",                     "SSH REMOTE SHELL COMMAND"},
        {"KAQPOBJST.OBJTYPE.ENUM.3",                      "JMX"},
        {"KAQPOBJST.OBJTYPE.ENUM.4",                      "SNMP"},
        {"KAQPOBJST.OBJTYPE.ENUM.5",                      "SHELL COMMAND"},
        {"KAQPOBJST.OBJTYPE.ENUM.6",                      "JOINED GROUPS"},
        {"KAQPOBJST.OBJTYPE.ENUM.7",                      "CIMOM"},
        {"KAQPOBJST.OBJTYPE.ENUM.8",                      "CUSTOM"},
        {"KAQPOBJST.OBJTYPE.ENUM.9",                      "ROLLUP DATA"},

        {"KAQPOBJST.OBJSTTS",                             "Object Status"},
        {"KAQPOBJST.OBJSTTS.ENUM.0",                      "ACTIVE"},
        {"KAQPOBJST.OBJSTTS.ENUM.1",                      "INACTIVE"},

        {"KAQPOBJST.ERRCODE",                             "Error Code"},
        {"KAQPOBJST.ERRCODE.ENUM.0",                      "NO ERROR"},
        {"KAQPOBJST.ERRCODE.ENUM.1",                      "GENERAL ERROR"},
        {"KAQPOBJST.ERRCODE.ENUM.10",                     "NO INSTANCES RETURNED"},
        {"KAQPOBJST.ERRCODE.ENUM.11",                     "ASSOCIATOR QUERY FAILED"},
        {"KAQPOBJST.ERRCODE.ENUM.12",                     "REFERENCE QUERY FAILED"},
        {"KAQPOBJST.ERRCODE.ENUM.13",                     "NO RESPONSE RECEIVED"},
        {"KAQPOBJST.ERRCODE.ENUM.14",                     "CANNOT FIND JOINED QUERY"},
        {"KAQPOBJST.ERRCODE.ENUM.15",                     "CANNOT FIND JOIN ATTRIBUTE IN QUERY 1 RESULTS"},
        {"KAQPOBJST.ERRCODE.ENUM.16",                     "CANNOT FIND JOIN ATTRIBUTE IN QUERY 2 RESULTS"},
        {"KAQPOBJST.ERRCODE.ENUM.17",                     "QUERY 1 NOT A SINGLETON"},
        {"KAQPOBJST.ERRCODE.ENUM.18",                     "QUERY 2 NOT A SINGLETON"},
        {"KAQPOBJST.ERRCODE.ENUM.19",                     "NO INSTANCES RETURNED IN QUERY 1"},
        {"KAQPOBJST.ERRCODE.ENUM.2",                      "OBJECT NOT FOUND"},
        {"KAQPOBJST.ERRCODE.ENUM.20",                     "NO INSTANCES RETURNED IN QUERY 2"},
        {"KAQPOBJST.ERRCODE.ENUM.21",                     "CANNOT FIND ROLLUP QUERY"},
        {"KAQPOBJST.ERRCODE.ENUM.22",                     "CANNOT FIND ROLLUP ATTRIBUTE"},
        {"KAQPOBJST.ERRCODE.ENUM.23",                     "FILE OFFLINE"},
        {"KAQPOBJST.ERRCODE.ENUM.24",                     "NO HOSTNAME"},
        {"KAQPOBJST.ERRCODE.ENUM.25",                     "MISSING LIBRARY"},
        {"KAQPOBJST.ERRCODE.ENUM.26",                     "ATTRIBUTE COUNT MISMATCH"},
        {"KAQPOBJST.ERRCODE.ENUM.27",                     "ATTRIBUTE NAME MISMATCH"},
        {"KAQPOBJST.ERRCODE.ENUM.28",                     "COMMON DATA PROVIDER NOT STARTED"},
        {"KAQPOBJST.ERRCODE.ENUM.29",                     "CALLBACK REGISTRATION ERROR"},
        {"KAQPOBJST.ERRCODE.ENUM.3",                      "COUNTER NOT FOUND"},
        {"KAQPOBJST.ERRCODE.ENUM.30",                     "MDL LOAD ERROR"},
        {"KAQPOBJST.ERRCODE.ENUM.31",                     "AUTHENTICATION FAILED"},
        {"KAQPOBJST.ERRCODE.ENUM.32",                     "CANNOT RESOLVE HOST NAME"},
        {"KAQPOBJST.ERRCODE.ENUM.33",                     "SUBNODE UNAVAILABLE"},
        {"KAQPOBJST.ERRCODE.ENUM.34",                     "SUBNODE NOT FOUND IN CONFIG"},
        {"KAQPOBJST.ERRCODE.ENUM.35",                     "ATTRIBUTE ERROR"},
        {"KAQPOBJST.ERRCODE.ENUM.36",                     "CLASSPATH ERROR"},
        {"KAQPOBJST.ERRCODE.ENUM.37",                     "CONNECTION FAILURE"},
        {"KAQPOBJST.ERRCODE.ENUM.38",                     "FILTER SYNTAX ERROR"},
        {"KAQPOBJST.ERRCODE.ENUM.39",                     "FILE NAME MISSING"},
        {"KAQPOBJST.ERRCODE.ENUM.4",                      "NAMESPACE ERROR"},
        {"KAQPOBJST.ERRCODE.ENUM.40",                     "SQL QUERY ERROR"},
        {"KAQPOBJST.ERRCODE.ENUM.41",                     "SQL FILTER QUERY ERROR"},
        {"KAQPOBJST.ERRCODE.ENUM.42",                     "SQL DB QUERY ERROR"},
        {"KAQPOBJST.ERRCODE.ENUM.43",                     "SQL DB FILTER QUERY ERROR"},
        {"KAQPOBJST.ERRCODE.ENUM.44",                     "PORT OPEN FAILED"},
        {"KAQPOBJST.ERRCODE.ENUM.45",                     "ACCESS DENIED"},
        {"KAQPOBJST.ERRCODE.ENUM.46",                     "TIMEOUT"},
        {"KAQPOBJST.ERRCODE.ENUM.47",                     "NOT IMPLEMENTED"},
        {"KAQPOBJST.ERRCODE.ENUM.48",                     "REQUESTED A BAD VALUE"},
        {"KAQPOBJST.ERRCODE.ENUM.49",                     "RESPONSE TOO BIG"},
        {"KAQPOBJST.ERRCODE.ENUM.5",                      "OBJECT CURRENTLY UNAVAILABLE"},
        {"KAQPOBJST.ERRCODE.ENUM.50",                     "GENERAL RESPONSE ERROR"},
        {"KAQPOBJST.ERRCODE.ENUM.51",                     "SCRIPT NONZERO RETURN"},
        {"KAQPOBJST.ERRCODE.ENUM.52",                     "SCRIPT NOT FOUND"},
        {"KAQPOBJST.ERRCODE.ENUM.53",                     "SCRIPT LAUNCH ERROR"},
        {"KAQPOBJST.ERRCODE.ENUM.54",                     "CONF FILE DOES NOT EXIST"},
        {"KAQPOBJST.ERRCODE.ENUM.55",                     "CONF FILE ACCESS DENIED"},
        {"KAQPOBJST.ERRCODE.ENUM.56",                     "INVALID CONF FILE"},
        {"KAQPOBJST.ERRCODE.ENUM.57",                     "EIF INITIALIZATION FAILED"},
        {"KAQPOBJST.ERRCODE.ENUM.58",                     "CANNOT OPEN FORMAT FILE"},
        {"KAQPOBJST.ERRCODE.ENUM.59",                     "FORMAT FILE SYNTAX ERROR"},
        {"KAQPOBJST.ERRCODE.ENUM.6",                      "COM LIBRARY INIT FAILURE"},
        {"KAQPOBJST.ERRCODE.ENUM.60",                     "REMOTE HOST UNAVAILABLE"},
        {"KAQPOBJST.ERRCODE.ENUM.61",                     "EVENT LOG DOES NOT EXIST"},
        {"KAQPOBJST.ERRCODE.ENUM.62",                     "PING FILE DOES NOT EXIST"},
        {"KAQPOBJST.ERRCODE.ENUM.63",                     "NO PING DEVICE FILES"},
        {"KAQPOBJST.ERRCODE.ENUM.64",                     "PING DEVICE LIST FILE MISSING"},
        {"KAQPOBJST.ERRCODE.ENUM.65",                     "SNMP MISSING PASSWORD"},
        {"KAQPOBJST.ERRCODE.ENUM.66",                     "DISABLED"},
        {"KAQPOBJST.ERRCODE.ENUM.67",                     "URLS FILE NOT FOUND"},
        {"KAQPOBJST.ERRCODE.ENUM.68",                     "XML PARSE ERROR"},
        {"KAQPOBJST.ERRCODE.ENUM.69",                     "NOT INITIALIZED"},
        {"KAQPOBJST.ERRCODE.ENUM.7",                      "SECURITY INIT FAILURE"},
        {"KAQPOBJST.ERRCODE.ENUM.70",                     "ICMP SOCKETS FAILED"},
        {"KAQPOBJST.ERRCODE.ENUM.71",                     "DUPLICATE CONF FILE"},
        {"KAQPOBJST.ERRCODE.ENUM.72",                     "DELETED CONFIGURATION"},
        {"KAQPOBJST.ERRCODE.ENUM.9",                      "PROXY SECURITY FAILURE"},

        {"KAQPOBJST.COLSTRT",                             "Last Collection Start"},
        {"KAQPOBJST.COLSTRT.ENUM.0000000000000001",       "NOT COLLECTED"},
        {"KAQPOBJST.COLSTRT.ENUM.0691231190000000",       "NOT COLLECTED"},

        {"KAQPOBJST.COLFINI",                             "Last Collection Finished"},
        {"KAQPOBJST.COLFINI.ENUM.0000000000000001",       "NOT COLLECTED"},
        {"KAQPOBJST.COLFINI.ENUM.0691231190000000",       "NOT COLLECTED"},

        {"KAQPOBJST.COLDURA",                             "Last Collection Duration"},

        {"KAQPOBJST.COLAVGD",                             "Average Collection Duration"},
        {"KAQPOBJST.COLAVGD.ENUM.-100",                   "NO DATA"},

        {"KAQPOBJST.REFRINT",                             "Refresh Interval"},

        {"KAQPOBJST.NUMCOLL",                             "Number of Collections"},

        {"KAQPOBJST.CACHEHT",                             "Cache Hits"},

        {"KAQPOBJST.CACHEMS",                             "Cache Misses"},

        {"KAQPOBJST.CACHPCT",                             "Cache Hit Percent"},

        {"KAQPOBJST.INTSKIP",                             "Intervals Skipped"},

};
return contents;
}

public Object[][] _oM15()
{
Object[][] contents = 
{
        {"TABLE.KAQTHPLST.OBJECT",                        "KAQ THREAD POOL STATUS"},
        {"KAQTHPLST.ORIGINNODE",                          "Node"},

        {"KAQTHPLST.TIMESTAMP",                           "Timestamp"},

        {"KAQTHPLST.THPSIZE",                             "Thread Pool Size"},
        {"KAQTHPLST.THPSIZE.ENUM.-1",                     "NO DATA"},
        {"KAQTHPLST.THPSIZE.ENUM.-100",                   "NO DATA"},

        {"KAQTHPLST.TPMAXSZ",                             "Thread Pool Max Size"},
        {"KAQTHPLST.TPMAXSZ.ENUM.-1",                     "NO DATA"},
        {"KAQTHPLST.TPMAXSZ.ENUM.-100",                   "NO DATA"},

        {"KAQTHPLST.TPACTTH",                             "Thread Pool Active Threads"},
        {"KAQTHPLST.TPACTTH.ENUM.-1",                     "NO DATA"},
        {"KAQTHPLST.TPACTTH.ENUM.-100",                   "NO DATA"},

        {"KAQTHPLST.TPAVGAT",                             "Thread Pool Avg Active Threads"},
        {"KAQTHPLST.TPAVGAT.ENUM.-1",                     "NO DATA"},
        {"KAQTHPLST.TPAVGAT.ENUM.-100",                   "NO DATA"},

        {"KAQTHPLST.TPMINAT",                             "Thread Pool Min Active Threads"},
        {"KAQTHPLST.TPMINAT.ENUM.-1",                     "NO DATA"},
        {"KAQTHPLST.TPMINAT.ENUM.-100",                   "NO DATA"},

        {"KAQTHPLST.TPMAXAT",                             "Thread Pool Max Active Threads"},
        {"KAQTHPLST.TPMAXAT.ENUM.-1",                     "NO DATA"},
        {"KAQTHPLST.TPMAXAT.ENUM.-100",                   "NO DATA"},

        {"KAQTHPLST.TPQLGTH",                             "Thread Pool Queue Length"},
        {"KAQTHPLST.TPQLGTH.ENUM.-1",                     "NO DATA"},
        {"KAQTHPLST.TPQLGTH.ENUM.-100",                   "NO DATA"},

        {"KAQTHPLST.TPAVGQL",                             "Thread Pool Avg Queue Length"},
        {"KAQTHPLST.TPAVGQL.ENUM.-1",                     "NO DATA"},
        {"KAQTHPLST.TPAVGQL.ENUM.-100",                   "NO DATA"},

        {"KAQTHPLST.TPMINQL",                             "Thread Pool Min Queue Length"},
        {"KAQTHPLST.TPMINQL.ENUM.-1",                     "NO DATA"},
        {"KAQTHPLST.TPMINQL.ENUM.-100",                   "NO DATA"},

        {"KAQTHPLST.TPMAXQL",                             "Thread Pool Max Queue Length"},
        {"KAQTHPLST.TPMAXQL.ENUM.-1",                     "NO DATA"},
        {"KAQTHPLST.TPMAXQL.ENUM.-100",                   "NO DATA"},

        {"KAQTHPLST.TPAVJBW",                             "Thread Pool Avg Job Wait"},
        {"KAQTHPLST.TPAVJBW.ENUM.-1",                     "NO DATA"},
        {"KAQTHPLST.TPAVJBW.ENUM.-100",                   "NO DATA"},

        {"KAQTHPLST.TPTJOBS",                             "Thread Pool Total Jobs"},
        {"KAQTHPLST.TPTJOBS.ENUM.-1",                     "NO DATA"},
        {"KAQTHPLST.TPTJOBS.ENUM.-100",                   "NO DATA"},

};
return contents;
}

public Object[][] _oM16()
{
Object[][] contents = 
{
        {"TABLE.KAQTACTST.OBJECT",                        "KAQ TAKE ACTION STATUS"},
        {"KAQTACTST.ORIGINNODE",                          "Node"},

        {"KAQTACTST.TIMESTAMP",                           "Timestamp"},

        {"KAQTACTST.TSKNAME",                             "Action Name"},

        {"KAQTACTST.TSKSTAT",                             "Action Status"},
        {"KAQTACTST.TSKSTAT.ENUM.0",                      "OK"},
        {"KAQTACTST.TSKSTAT.ENUM.1",                      "NOT APPLICABLE"},
        {"KAQTACTST.TSKSTAT.ENUM.10",                     "UNKNOWN"},
        {"KAQTACTST.TSKSTAT.ENUM.11",                     "DEPENDENT STILL RUNNING"},
        {"KAQTACTST.TSKSTAT.ENUM.12",                     "INSUFFICIENT USER AUTHORITY"},
        {"KAQTACTST.TSKSTAT.ENUM.2",                      "GENERAL ERROR"},
        {"KAQTACTST.TSKSTAT.ENUM.3",                      "WARNING"},
        {"KAQTACTST.TSKSTAT.ENUM.4",                      "NOT RUNNING"},
        {"KAQTACTST.TSKSTAT.ENUM.5",                      "DEPENDENT NOT RUNNING"},
        {"KAQTACTST.TSKSTAT.ENUM.6",                      "ALREADY RUNNING"},
        {"KAQTACTST.TSKSTAT.ENUM.7",                      "PREREQ NOT RUNNING"},
        {"KAQTACTST.TSKSTAT.ENUM.8",                      "TIMED OUT"},
        {"KAQTACTST.TSKSTAT.ENUM.9",                      "DOESNT EXIST"},

        {"KAQTACTST.TSKAPRC",                             "Action App Return Code"},

        {"KAQTACTST.TSKMSGE",                             "Action Message"},

        {"KAQTACTST.TSKINST",                             "Action Instance"},

        {"KAQTACTST.TSKOUTP",                             "Action Results"},

        {"KAQTACTST.TSKCMND",                             "Action Command"},

        {"KAQTACTST.TSKORGN",                             "Action Node"},

        {"KAQTACTST.TSKSBND",                             "Action Subnode"},

        {"KAQTACTST.TSKID",                               "Action ID"},

        {"KAQTACTST.TSKTYPE",                             "Action Type"},
        {"KAQTACTST.TSKTYPE.ENUM.0",                      "UNKNOWN"},
        {"KAQTACTST.TSKTYPE.ENUM.1",                      "AUTOMATION"},

        {"KAQTACTST.TSKOWNR",                             "Action Owner"},

};
return contents;
}

public Object[][] _oM17()
{
Object[][] contents = 
{
        {"TABLE.KAQSTRING.OBJECT",                        "KAQ STRING NOTIFICATIONS"},
        {"KAQSTRING.ORIGINNODE",                          "Node"},

        {"KAQSTRING.TIMESTAMP",                           "Timestamp"},

        {"KAQSTRING.NOTIFICATI",                          "Notification Type"},

        {"KAQSTRING.MONITOR_ID",                          "Monitor ID"},
        {"KAQSTRING.MONITOR_ID.ENUM.-2147483648",         "Value Exceeds Minimum"},
        {"KAQSTRING.MONITOR_ID.ENUM.2147483647",          "Value Exceeds Maximum"},

        {"KAQSTRING.OBSERVED_M",                          "Observed MBean"},

        {"KAQSTRING.OBSERVED_A",                          "Observed Attribute"},

        {"KAQSTRING.COMPARE_ST",                          "Compare String"},

        {"KAQSTRING.STRING_VAL",                          "String Value"},

        {"KAQSTRING.NOTIFICAT0",                          "Notification Time Stamp"},

        {"KAQSTRING.NOTIFICAT1",                          "Notification Message"},

};
return contents;
}

public Object[][] _oM18()
{
Object[][] contents = 
{
        {"TABLE.KAQGAUGE.OBJECT",                         "KAQ GAUGE NOTIFICATIONS"},
        {"KAQGAUGE.ORIGINNODE",                           "Node"},

        {"KAQGAUGE.TIMESTAMP",                            "Timestamp"},

        {"KAQGAUGE.NOTIFICATI",                           "Notification Type"},

        {"KAQGAUGE.MONITOR_ID",                           "Monitor ID"},
        {"KAQGAUGE.MONITOR_ID.ENUM.-2147483648",          "Value Exceeds Minimum"},
        {"KAQGAUGE.MONITOR_ID.ENUM.2147483647",           "Value Exceeds Maximum"},

        {"KAQGAUGE.OBSERVED_M",                           "Observed MBean"},

        {"KAQGAUGE.OBSERVED_A",                           "Observed Attribute"},

        {"KAQGAUGE.LOW_THRESH",                           "Low Threshold"},

        {"KAQGAUGE.HIGH_THRES",                           "High Threshold"},

        {"KAQGAUGE.GAUGE_VALU",                           "Gauge Value"},
        {"KAQGAUGE.GAUGE_VALU.ENUM.-2147483648",          "Value Exceeds Minimum"},
        {"KAQGAUGE.GAUGE_VALU.ENUM.2147483647",           "Value Exceeds Maximum"},

        {"KAQGAUGE.NOTIFICAT0",                           "Notification Time Stamp"},

        {"KAQGAUGE.NOTIFICAT1",                           "Notification Message"},

};
return contents;
}

public Object[][] _oM19()
{
Object[][] contents = 
{
        {"TABLE.KAQCOUNTER.OBJECT",                       "KAQ COUNTER NOTIFICATIONS"},
        {"KAQCOUNTER.ORIGINNODE",                         "Node"},

        {"KAQCOUNTER.TIMESTAMP",                          "Timestamp"},

        {"KAQCOUNTER.NOTIFICATI",                         "Notification Type"},

        {"KAQCOUNTER.MONITOR_ID",                         "Monitor ID"},
        {"KAQCOUNTER.MONITOR_ID.ENUM.-2147483648",        "Value Exceeds Minimum"},
        {"KAQCOUNTER.MONITOR_ID.ENUM.2147483647",         "Value Exceeds Maximum"},

        {"KAQCOUNTER.OBSERVED_M",                         "Observed MBean"},

        {"KAQCOUNTER.OBSERVED_A",                         "Observed Attribute"},

        {"KAQCOUNTER.THRESHOLD",                          "Threshold"},

        {"KAQCOUNTER.OFFSET",                             "Offset"},

        {"KAQCOUNTER.MODULUS",                            "Modulus"},
        {"KAQCOUNTER.MODULUS.ENUM.-2147483648",           "Value Exceeds Minimum"},
        {"KAQCOUNTER.MODULUS.ENUM.2147483647",            "Value Exceeds Maximum"},

        {"KAQCOUNTER.COUNTER_VA",                         "Counter Value"},
        {"KAQCOUNTER.COUNTER_VA.ENUM.-2147483648",        "Value Exceeds Minimum"},
        {"KAQCOUNTER.COUNTER_VA.ENUM.2147483647",         "Value Exceeds Maximum"},

        {"KAQCOUNTER.NOTIFICAT0",                         "Notification Time Stamp"},

        {"KAQCOUNTER.NOTIFICAT1",                         "Notification Message"},

};
return contents;
}

public Object[][] _oM20()
{
Object[][] contents = 
{
        {"TABLE.KAQREGMONS.OBJECT",                       "KAQ REGISTERED MONITORS"},
        {"KAQREGMONS.ORIGINNODE",                         "Node"},

        {"KAQREGMONS.TIMESTAMP",                          "Timestamp"},

        {"KAQREGMONS.MONITOR_ID",                         "Monitor ID"},
        {"KAQREGMONS.MONITOR_ID.ENUM.-2147483648",        "Value Exceeds Minimum"},
        {"KAQREGMONS.MONITOR_ID.ENUM.2147483647",         "Value Exceeds Maximum"},

        {"KAQREGMONS.MONITOR_PA",                         "Monitor Parameters"},

        {"KAQREGMONS.MONITOR_NA",                         "Monitor Name"},

};
return contents;
}

 
  /**
   * Provide access to singleton Bundle wrapper for this resource bundle.
   *
   * @return reference to Bundle wrapper for this resource bundle
   */
//  Begin do not translate block
  public static final Bundle getBundle()
  {
    // if singleton bundle not yet created ...
    if (bundle == null)
    {
      // ... create it now
      bundle = new Bundle(BUNDLE_ID, BUNDLE_NAME, BundleManager.getCurrentLocale());
      BundleManager.addBundle(bundle);

      // make long-lived reference to singleton instance
      SingletonManager.add(bundle);
    }

    // return result
    return bundle;
  }

  /**
   * Implements Versioned interface
   */
  public Object getVersion()
  {
    return version.getVersion();
  }

  /**
   * Implements Versioned interface
   */
  public int compareVersion(Object targetVersion)
  {
    return version.compareVersion(targetVersion);
  }

  /**
   * Implementation of ResourceBundle.getKeys.
   */
  public Enumeration getKeys()
  {
    if (map.isEmpty())
      loadMap();

    return new Enumeration()
    {
      private Iterator mi = map.keySet().iterator();

      public boolean hasMoreElements()
      {
        return mi.hasNext();
      }

      public Object nextElement()
      {
        return mi.next();
      }
    };
  }

  /**
   * Gets an object for the given key from this resource bundle.
   * Returns null if this resource bundle does not contain an
   * object for the given key.
   *
   * @param key the key for the desired object
   * @exception NullPointerException if <code>key</code> is <code>null</code>
   * @return the object for the given key, or null
   */
  public Object handleGetObject(String key)
  {
    if (key == null)
      throw new NullPointerException();

    if (map.isEmpty())
      loadMap();

    return map.get(key); 
  }

  // load the resource map
  private void loadMap() 
  {
    Method[] methods = getClass().getDeclaredMethods();

    try
    {
      for (int i=0; i < methods.length; i++)
      {
        Method method = methods[i];

        if (method.getName().startsWith("_oM")) // one of the resource methods
        {
          Object[][] contents = (Object[][])method.invoke(this, (Object[]) null);

          for (int j = 0; j < contents.length; ++j)
          {
            map.put((String)contents[j][0], contents[j][1]);
          }
        }
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }

  private static Bundle bundle;
  private static HashMap map = new HashMap(43);
//End do not translate block
}
