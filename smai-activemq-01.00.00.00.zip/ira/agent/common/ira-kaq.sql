/* ---------------------------------------------------------- */
/* @(#) KAQ.SQL V100                */
/* ---------------------------------------------------------- */
/* Product Provided Situations and Templates for              */
/* ActiveMQ Monitoring Agent  */
/*                                                            */
/* Licensed Materials - Property of IBM                       */
/* Copyright IBM Corp. 2005, 2017 All Rights Reserved               */
/* US Government Users Restricted Rights - Use, duplication or*/
/* disclosure restricted by GSA ADP Schedule Contract with    */
/* IBM Corp.                                                  */
/*                                                            */
/* Warning: this file contains ascii binary data that cannot  */
/*          be ftp'ed as TEXT between ascii and ebcdic hosts. */
/* ---------------------------------------------------------- */


/* ---------------------------------------------------------- */
/* General section.  Applies to all products                  */
/* ---------------------------------------------------------- */

/* Tasks */

/* JMX Add String Metric Watcher */
DELETE FROM O4SRV.CCT
WHERE KEY = "KAQ_JMX_ADD_STRING_WATCHER";

INSERT INTO O4SRV.CCT
(
   AFFINITIES,
   CMD,
   DESC,
   ICON,
   KEY,
   NAME,
   RESERVED,
   SECURITY,
   TABLES,
   VERSION
)
VALUES
(
  "%IBM.KAQ                000000000000000000", 
  "JMX_ADD_STRING_METRIC_WATCHER [&MBeanName] [&ObservedAttribute]
 [&NotifyMatch] [&NotifyDiffer] [&StringToCompare]",
  "Monitor MBeans string attribute for matching or non-matching values."
,
  " ", 
  "KAQ_JMX_ADD_STRING_WATCHER", 
  "JMX Add String Metric Watcher", 
  " ", 
  " ", 
  " ", 
  " " 
);

/* JMX Add Gauge Metric Watcher */
DELETE FROM O4SRV.CCT
WHERE KEY = "KAQ_JMX_ADD_GAUGE_WATCHER";

INSERT INTO O4SRV.CCT
(
   AFFINITIES,
   CMD,
   DESC,
   ICON,
   KEY,
   NAME,
   RESERVED,
   SECURITY,
   TABLES,
   VERSION
)
VALUES
(
  "%IBM.KAQ                000000000000000000", 
  "JMX_ADD_GAUGE_METRIC_WATCHER [&MBeanName] [&ObservedAttribute]
 [&DifferenceMode] [&NotifyHigh] [&NotifyLow] [&HighThreshold]
 [&LowThreshold]",
  "Monitor MBeans numeric attribute going outside a range of acceptable
 values.",
  " ", 
  "KAQ_JMX_ADD_GAUGE_WATCHER", 
  "JMX Add Gauge Metric Watcher", 
  " ", 
  " ", 
  " ", 
  " " 
);

/* JMX Add Counter Metric Watcher */
DELETE FROM O4SRV.CCT
WHERE KEY = "KAQ_JMX_ADD_COUNTER_WATCHER";

INSERT INTO O4SRV.CCT
(
   AFFINITIES,
   CMD,
   DESC,
   ICON,
   KEY,
   NAME,
   RESERVED,
   SECURITY,
   TABLES,
   VERSION
)
VALUES
(
  "%IBM.KAQ                000000000000000000", 
  "JMX_ADD_COUNTER_METRIC_WATCHER [&MBeanName] [&ObservedAttribute]
 [&InitialThreshold] [&Offset] [&Modulus] [&DifferenceMode]
 [&GranularityPeriod]",
  "Monitor MBeans numeric counter going past a defined threshold.",
  " ", 
  "KAQ_JMX_ADD_COUNTER_WATCHER", 
  "JMX Add Counter Metric Watcher", 
  " ", 
  " ", 
  " ", 
  " " 
);

/* JMX Delete Metric watcher */
DELETE FROM O4SRV.CCT
WHERE KEY = "KAQ_JMX_DELETE_WATCHER";

INSERT INTO O4SRV.CCT
(
   AFFINITIES,
   CMD,
   DESC,
   ICON,
   KEY,
   NAME,
   RESERVED,
   SECURITY,
   TABLES,
   VERSION
)
VALUES
(
  "%IBM.KAQ                000000000000000000", 
  "JMX_DELETE_METRIC_WATCHER [&Monitor_ID]",
  "Delete a JMX metric watcher.",
  " ", 
  "KAQ_JMX_DELETE_WATCHER", 
  "JMX Delete Metric watcher", 
  " ", 
  " ", 
  " ", 
  " " 
);

/* JMX Invoke */
DELETE FROM O4SRV.CCT
WHERE KEY = "KAQ_JMX_INVOKE";

INSERT INTO O4SRV.CCT
(
   AFFINITIES,
   CMD,
   DESC,
   ICON,
   KEY,
   NAME,
   RESERVED,
   SECURITY,
   TABLES,
   VERSION
)
VALUES
(
  "%IBM.KAQ                000000000000000000", 
  "JMX_INVOKE [&MBeanName] [&Operation] [&Argument1] [&Argument2]
 [&Argument3] [&Argument4]",
  "Invoke an operation against an MBean.",
  " ", 
  "KAQ_JMX_INVOKE", 
  "JMX Invoke", 
  " ", 
  " ", 
  " ", 
  " " 
);

/* Situations */
