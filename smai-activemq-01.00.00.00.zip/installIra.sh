#!/bin/sh
# ----------------------------------------------------------------
# Monitoring Agent for ActiveMQ
# Version 100
# Installation Script for Unix
#
# IBM
#
# This file was created by IBM Agent Builder
# Version 6.3.4
#	Agent Builder Common.v6.3.4 201703151048
#	IBM Tivoli Monitoring Agent Generator.v6.3.4 201703151048
#	IBM Agent Builder UI.v6.3.4 201703151048
#	IBM Tivoli Monitoring OSLC Plugin.v6.3.4 201703151048
#	Agent Builder CIM Data Provider.v6.3.4 201703151048
#	Agent Builder Custom Data Provider.v6.3.4 201703151048
#	Agent Builder HTTP Data Provider.v6.3.4 201703151048
#	Agent Builder ICMP Data Provider.v6.3.4 201703151048
#	IBM Tivoli Monitoring JDBC Data Provider.v6.3.4 201703151048
#	IBM Tivoli Monitoring JMX Data Provider.v6.3.4 201703151048
#	Agent Builder Log Data Provider.v6.3.4 201703151048
#	Agent Builder SNMP Data Provider.v6.3.4 201703151048
#	Agent Builder WMI Data Provider.v6.3.4 201703151048
#	IBM Tivoli Monitoring TMS DLA Plugin.v6.3.4 201703151048
#	Agent Builder Dashboard Support.v6.3.4 201703151048
#	IBM Tivoli Monitoring Remote Deploy.v6.3.4 201703151048
#	IBM Tivoli Omnibus.v6.3.4 201703151048
# ----------------------------------------------------------------

usage()
{
    echo "usage InstallIra.sh <ITM home> [[-h <HUB TEMS hostname>] -u <HUB TEMS username> [-p <HUB TEMS password>]] [-r]"
    echo "Where -r indicates that the TEPS should be restarted"
    echo "If HUB TEMS and Username are provided but password is not, you will be prompted for the password"
    exit 1
}

CANDLE_HOME=$1
export CANDLE_HOME
unset NO_RESTART_TEMS
unset HUB_TEMS_HOST
unset HUB_TEMS_USER
unset HUB_TEMS_PASS
RESTART_TEPS=0
while [ -n "$1" ]
do
    shift
    case "$1" in
        "-n") NO_RESTART_TEMS="-n"
        ;;
        "-h") HUB_TEMS_HOST="$2"
        ;;
        "-u") HUB_TEMS_USER="$2"
        ;;
        "-p") HUB_TEMS_PASS="$2"
        ;;
        "-r") RESTART_TEPS=1
        ;;
    esac
done

if [ -z "$CANDLE_HOME"  ]; then
    usage
fi

if [ -n "$HUB_TEMS_HOST"  ]; then
    if [ -z "$HUB_TEMS_USER" ]; then
        usage
    fi
fi

if [ -n "$HUB_TEMS_USER"  ]; then
    if [ -z "$HUB_TEMS_HOST" ]; then
        HUB_TEMS_HOST=localhost
    fi
fi

# Call the agent install script.
./installIraAgent.sh ${CANDLE_HOME}
if [ $? -ne 0 ]; then
    exit 1
fi

# Call the TEMS install script.
if [ -n "${HUB_TEMS_HOST}" ]; then
    if [ -n "${HUB_TEMS_PASS}" ]; then
        ./installIraAgentTEMS.sh "${CANDLE_HOME}" -h $HUB_TEMS_HOST -u $HUB_TEMS_USER -p "$HUB_TEMS_PASS" 
    else
        ./installIraAgentTEMS.sh "${CANDLE_HOME}" -h $HUB_TEMS_HOST -u $HUB_TEMS_USER 
    fi
else
    ./installIraAgentTEMS.sh "${CANDLE_HOME}" $NO_RESTART_TEMS
fi
if [ $? -ne 0 ]; then
    exit 1
fi

# Call the TEPS install script.
if [ -z "$HUB_TEMS_USER" ]; then
    # No TEMS users, so restart the TEPS
    ./installIraAgentTEPS.sh ${CANDLE_HOME} -r
else
    if [ "$RESTART_TEPS" -eq "1" ]; then
        ./installIraAgentTEPS.sh ${CANDLE_HOME} -r
    else
        ./installIraAgentTEPS.sh ${CANDLE_HOME}
    fi
fi
if [ $? -ne 0 ]; then
    exit 1
fi

exit 0
